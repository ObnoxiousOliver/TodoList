-- INSTALL TODO LIST --

1. Extract zip

2. Open "TodoListInstaller.exe"

3. Choose directory / version

4. Hit INSTALL


-- UPDATE TODO LIST --

1. Extract zip

2. Open "TodoListInstaller.exe"

3. Check OVERRIDE CONTENT

3. Choose directory of already installed version

4. Choose version

5. Hit INSTALL